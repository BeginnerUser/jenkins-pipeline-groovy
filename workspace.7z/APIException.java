package com.common.core;

@Getter
public class APIException extends RuntimeException{

    int code;

    String msg;

    public APIException(){
    }

    public APIException(String msg){
        this.msg =msg;
    }

    public APIException(int code,String msg){
        super(msg);
        this.code = code;
        this.msg =msg;
    }
}

