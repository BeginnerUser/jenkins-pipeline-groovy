package com.common.core;

@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * 参数检验失败异常处理
     * @param e 异常
     * @return
     */
    @ExceptionHandler(MethodArgumentNotVaildException.class)
    public ResultVO<String> MethodArgumentNotVaildExceptionHandler(MethodArgumentNotVaildException e){
        // 从异常对象中拿到ObjectError对象
        ObjectError objectError = e.getBindingResult().getAllErrors().get(0);
        // 提取错误信息返回
        return new ResultVO<String>(ResultCode.FAILED,objectError.getDefaultMessage());
    }

    /**
     * 接口返回异常处理
     * @param e
     * @return
     */
    @ExceptionHandler(value = APIException.class)
    public ResultVO<String> APIExceptionHandler(APIException e){
        return new ResultVO<>(ResultCode.FAILED,e.getMsg());
    }

    /**
     * 空指针异常处理
     * @param e
     * @return
     */
    @Exceptionhandler(value = NullPointerException.class)
    public String NullExceptionHandler(NullPointerException e){
        return e.getMessage();
    }

}
