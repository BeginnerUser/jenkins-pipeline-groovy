package com.common.core;

@Getter
public enum ResultCode {

    SUCCESS(200,"成功！"),
    ERROR(300,"未知错误，请再次尝试！"),
    FAILED(500,"服务器未响应，请联系联系员！"),
    NOT404(404,"未找到页面，请重新尝试！"),
    VALIDATE_FAILED(101,"参数校验失败！");

    int code;
    String msg;

    ResultCode(int code,String msg){
        this.code = code;
        this.msg = msg;
    }
}
