package com.common.core;

@Getter
public class ResultVO<T> {

    int code;

    String msg;


    T data;

    public ResultVO(){
    }

    public ResultVO(String msg){
        this.msg=msg;
    }

    public ResultVO(int code,String msg){
        this.code =code;
        this.msg =msg;
    }

    public ResultVO(int code,String msg,T data){
        this.code =code;
        this.msg =msg;
        this.data =data;
    }
}
